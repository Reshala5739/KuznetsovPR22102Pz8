﻿namespace Snake
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.difficulty = new System.Windows.Forms.ToolStripMenuItem();
            this.difficultyL = new System.Windows.Forms.ToolStripMenuItem();
            this.difficultyN = new System.Windows.Forms.ToolStripMenuItem();
            this.difficultyH = new System.Windows.Forms.ToolStripMenuItem();
            this.SnakeFruit = new System.Windows.Forms.ToolStripMenuItem();
            this.Color = new System.Windows.Forms.ToolStripMenuItem();
            this.руководствоToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оНасToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.управлениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.паузаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.пускEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lbPause = new System.Windows.Forms.Label();
            this.lbS = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.difficulty,
            this.SnakeFruit,
            this.руководствоToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1384, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // difficulty
            // 
            this.difficulty.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.difficultyL,
            this.difficultyN,
            this.difficultyH});
            this.difficulty.Name = "difficulty";
            this.difficulty.Size = new System.Drawing.Size(81, 20);
            this.difficulty.Text = "Сложность";
            // 
            // difficultyL
            // 
            this.difficultyL.Name = "difficultyL";
            this.difficultyL.Size = new System.Drawing.Size(180, 22);
            this.difficultyL.Text = "Легко";
            this.difficultyL.Click += new System.EventHandler(this.difficultyL_Click);
            // 
            // difficultyN
            // 
            this.difficultyN.Checked = true;
            this.difficultyN.CheckState = System.Windows.Forms.CheckState.Checked;
            this.difficultyN.Name = "difficultyN";
            this.difficultyN.Size = new System.Drawing.Size(180, 22);
            this.difficultyN.Text = "Нормально";
            this.difficultyN.Click += new System.EventHandler(this.difficultyN_Click);
            // 
            // difficultyH
            // 
            this.difficultyH.Name = "difficultyH";
            this.difficultyH.Size = new System.Drawing.Size(180, 22);
            this.difficultyH.Text = "Сложно";
            this.difficultyH.Click += new System.EventHandler(this.difficultyH_Click);
            // 
            // SnakeFruit
            // 
            this.SnakeFruit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Color});
            this.SnakeFruit.Name = "SnakeFruit";
            this.SnakeFruit.Size = new System.Drawing.Size(75, 20);
            this.SnakeFruit.Text = "Цвет змеи";
            // 
            // Color
            // 
            this.Color.Name = "Color";
            this.Color.Size = new System.Drawing.Size(180, 22);
            this.Color.Text = "Цвет";
            this.Color.Click += new System.EventHandler(this.Color_Click);
            // 
            // руководствоToolStripMenuItem
            // 
            this.руководствоToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оНасToolStripMenuItem,
            this.управлениеToolStripMenuItem});
            this.руководствоToolStripMenuItem.Name = "руководствоToolStripMenuItem";
            this.руководствоToolStripMenuItem.Size = new System.Drawing.Size(88, 20);
            this.руководствоToolStripMenuItem.Text = "Руководство";
            // 
            // оНасToolStripMenuItem
            // 
            this.оНасToolStripMenuItem.Name = "оНасToolStripMenuItem";
            this.оНасToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.оНасToolStripMenuItem.Text = "О нас ";
            // 
            // управлениеToolStripMenuItem
            // 
            this.управлениеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.паузаToolStripMenuItem,
            this.пускEToolStripMenuItem});
            this.управлениеToolStripMenuItem.Name = "управлениеToolStripMenuItem";
            this.управлениеToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.управлениеToolStripMenuItem.Text = "Управление";
            // 
            // паузаToolStripMenuItem
            // 
            this.паузаToolStripMenuItem.Name = "паузаToolStripMenuItem";
            this.паузаToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.паузаToolStripMenuItem.Text = "Пауза    \"Space\"";
            // 
            // пускEToolStripMenuItem
            // 
            this.пускEToolStripMenuItem.Name = "пускEToolStripMenuItem";
            this.пускEToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.пускEToolStripMenuItem.Text = "Продолжить \"Q\"";
            // 
            // lbPause
            // 
            this.lbPause.AutoSize = true;
            this.lbPause.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.lbPause.ForeColor = System.Drawing.Color.Red;
            this.lbPause.Location = new System.Drawing.Point(282, 326);
            this.lbPause.Name = "lbPause";
            this.lbPause.Size = new System.Drawing.Size(184, 55);
            this.lbPause.TabIndex = 1;
            this.lbPause.Text = "ПАУЗА";
            // 
            // lbS
            // 
            this.lbS.AutoSize = true;
            this.lbS.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.lbS.Location = new System.Drawing.Point(213, 398);
            this.lbS.Name = "lbS";
            this.lbS.Size = new System.Drawing.Size(343, 26);
            this.lbS.TabIndex = 2;
            this.lbS.Text = "Чтобы продолжить нажмите \"Q\"";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1384, 671);
            this.Controls.Add(this.lbS);
            this.Controls.Add(this.lbPause);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem difficulty;
        private System.Windows.Forms.ToolStripMenuItem difficultyL;
        private System.Windows.Forms.ToolStripMenuItem difficultyN;
        private System.Windows.Forms.ToolStripMenuItem difficultyH;
        private System.Windows.Forms.ToolStripMenuItem SnakeFruit;
        private System.Windows.Forms.ToolStripMenuItem руководствоToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оНасToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Color;
        private System.Windows.Forms.ToolStripMenuItem управлениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem паузаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem пускEToolStripMenuItem;
        private System.Windows.Forms.Label lbPause;
        private System.Windows.Forms.Label lbS;
    }
}

